﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Cache;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace HomeWork
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static MyDB db;

        public MainWindow()
        {
            InitializeComponent();

            db = new MyDB();

            UpdateEmplList();
            DepList.DataContext = db.DepList().DefaultView;

        }

        private void UpdateEmplList()
        {
            
            EmplList.DataContext = db.EmplList().DefaultView;
        }

        private void EmplList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
           
        }

        /// <summary>
        /// Изменение данных по сотруднику
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (EmplList.SelectedItem != null)
            {
                int n = EmplList.SelectedIndex;
                DataRowView newRow = (DataRowView)EmplList.SelectedItem;
                newRow.BeginEdit();
                EditWindow EditWindow = new EditWindow(newRow.Row);
                //EditWindow.Owner = this;
                
                EditWindow.ShowDialog();
                if (EditWindow.DialogResult.HasValue && EditWindow.DialogResult.Value)
                {
                    newRow.EndEdit();
                    db.adapter.Update(db.EmplList());
                }
                else
                {
                    newRow.CancelEdit();
                }
            }

        }

        /// <summary>
        /// Добавление нвого сотрудника
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddEmpl addEmpl = new AddEmpl();
            
            addEmpl.ShowDialog();
            if (addEmpl.DialogResult.HasValue && addEmpl.DialogResult.Value)
            {
                
                db.adapter.Update(db.EmplList());
                UpdateEmplList();
            }
        }

        private void BtnEditDep_Click(object sender, RoutedEventArgs e)
        {
            if (DepList.SelectedItem != null)
            {
                int n = DepList.SelectedIndex;
                DataRowView newRow = (DataRowView)DepList.SelectedItem;
                newRow.BeginEdit();
                EditDepWindow EditDepWindow = new EditDepWindow(newRow.Row);
                //EditWindow.Owner = this;

                EditDepWindow.ShowDialog();
                if (EditDepWindow.DialogResult.HasValue && EditDepWindow.DialogResult.Value)
                {
                    newRow.EndEdit();
                    db.adapter.Update(db.DepList());
                    UpdateEmplList();
                }
                else
                {
                    newRow.CancelEdit();
                }
            }
        }

        private void BtnAddDep_Click(object sender, RoutedEventArgs e)
        {
            AddDepWindow addDep = new AddDepWindow();
            addDep.ShowDialog();
            if (addDep.DialogResult.HasValue && addDep.DialogResult.Value)
            {

                DepList.DataContext = db.DepList().DefaultView;
                UpdateEmplList();
            }
        
        }
    }
}
