﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomeWork
{
    /// <summary>
    /// Логика взаимодействия для EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        MyDB db;
        public DataRow resultRow { get; set; }
        public EditWindow(DataRow row)
        {
            InitializeComponent();
            db = MainWindow.db;
            resultRow = row;

        }

        

        ///// <summary>
        ///// Получаем данные сотрудника
        ///// </summary>
        public void GetEmpl()
        {
            
            EmplName.Text = resultRow["NAME"].ToString();
            EmplAge.Text = resultRow["AGE"].ToString();
            
           // DepBox.DataContext= db.DepList().DefaultView;
            var v = db.DepList().DefaultView;
            v.Sort = "ID ASC";
            DepBox.DataContext = v;

            
            var selDepName = db.DepOne(Convert.ToInt32(resultRow["IDDEP"]));
            foreach (DataRowView dr in v)
            {
                if (dr["NAME"].ToString() == selDepName)
                    DepBox.SelectedItem = dr;
            }
            
        }

        private void SaveBTN_Click(object sender, RoutedEventArgs e)
        {
            resultRow["NAME"] = EmplName.Text;
            resultRow["AGE"] = Convert.ToInt32(EmplAge.Text);
            DataRowView newRow = (DataRowView)DepBox.SelectedItem;
            resultRow["IDDEP"] = newRow["ID"];
            resultRow["DEP"] = newRow["NAME"];
            
           
            db.UpdateEmpl(Convert.ToInt32(resultRow["ID"]), EmplName.Text, Convert.ToInt32(EmplAge.Text),Convert.ToInt32( newRow["ID"].ToString()));
            DialogResult = true;
            

            //this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetEmpl();
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
