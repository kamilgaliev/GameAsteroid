﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork
{
    public class Employee : INotifyPropertyChanged
    {
        private int id;
        private string name;
        private int age;
        private int iddep;
        private string depname;

        public int Id
        {
            get { return this.id; }
            set
            {
                this.id = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(this.Id)));
                
            }
        }

        public string Name
        {
            get { return this.name; }
            set
            {
                this.name = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(this.Name)));
                
            }
        }
        public int Age
        {
            get { return this.age; }
            set
            {
                this.age = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(this.Age)));
                
            }
        }

        public int IdDep
        {
            get { return this.iddep; }
            set
            {
               this.iddep = value;
               PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(this.IdDep)));
                
            }
        }

        public string DepName
        {
            get { return this.depname; }
            set
            {
                 this.depname = value;
                 PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(this.DepName)));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        
        
    }
}
