﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace WpfTestMailSender.Model
{
    class EmailSender
    {
        public void Send(MailMessage message, string server,string port, string pass)
        {
            
            
            try
            {
                
                string subject = message.Subject;
               
                string body = message.Body;


                var smtp = new SmtpClient()
                {
                    Host = server,
                    Port = Convert.ToInt32(port),
                    EnableSsl = true,
                    Timeout = 10000,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(message.From.Address, pass)
                };
                smtp.Send(message);
                
                System.Windows.MessageBox.Show("Письмо отправлено");
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }


        }
    }
}
