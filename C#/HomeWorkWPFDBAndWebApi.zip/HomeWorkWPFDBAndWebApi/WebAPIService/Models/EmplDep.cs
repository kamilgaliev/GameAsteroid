﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAPIService.Models
{
    public class EmplDep
    {
        public int IdEmpl { get; set; }
        public int IdDep { get; set; }
    }
}