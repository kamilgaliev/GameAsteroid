﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfTestMailSender
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class WpfMailSender : Window
    {
        public WpfMailSender()
        {
            InitializeComponent();
        }

        private void btnSend_Click(object sender, RoutedEventArgs e)
        {
            Model.EmailSender emailSender = new Model.EmailSender();

            MailMessage mail = new MailMessage(tbUserName.Text, txbTo.Text);
            //mail.From = new MailAddress(tbUserName.Text);
            //mail.To.Add(new MailAddress( txbTo.Text));
            mail.Subject = txbSubject.Text;
            mail.Body = txbBody.Text;


            emailSender.Send(mail,tbServer.Text,tbPort.Text,tbPassword.Password);
        }
    }
}
