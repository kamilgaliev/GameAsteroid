﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Cache;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using HomeWork.Department;
using HomeWork.Employee;

namespace HomeWork
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// items - список сотрудников
        /// itemsDept - список отделов
        /// </summary>
        public ObservableCollection<Employee.Employee> items = new ObservableCollection<Employee.Employee>();
        public ObservableCollection<Department.Department> itemsDept = new ObservableCollection<Department.Department>();
        public MainWindow()
        {
            InitializeComponent();
            FillList();
        }

        /// <summary>
        /// Добавление элементов в список
        /// </summary>
        void FillList()
        {

            itemsDept.Add(new Department.Department() { Id = 1, Name ="Отдел 1"});
            itemsDept.Add(new Department.Department() { Id = 2, Name = "Отдел 2" });

            items.Add(new Employee.Employee() { Id = 1, Name = "Vasya", Age = 22, IdDep = 1});
            items.Add(new Employee.Employee() { Id = 2, Name = "Petya", Age = 25, IdDep = 2 });
            items.Add(new Employee.Employee() { Id = 3, Name = "Kolya", Age = 23, IdDep = 1 });

            UpdateEmplList();
            DepList.ItemsSource = itemsDept;
        }

        /// <summary>
        /// Объединение списка сотрудник и отдел. Вывод ид сотр, имя, возраст и название отдела
        /// </summary>
        private void UpdateEmplList()
        {
            var EmplQuery = from emp in items
                            join dep in itemsDept
                            on emp.IdDep equals dep.Id
                            select new Employee.Employee
                            {
                                Id = emp.Id,
                                Name = emp.Name,
                                Age = emp.Age,
                                DepName = dep.Name
                            };
            EmplList.ItemsSource = null;
            EmplList.ItemsSource = EmplQuery;
        }


        //private void EmplList_Selected(object sender, RoutedEventArgs e)
        //{
        //    MessageBox.Show(e.Source.ToString());
        //}


        private void EmplList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
           
        }

        /// <summary>
        /// Изменение данных по сотруднику
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (EmplList.SelectedItem != null)
            {
                int n = EmplList.SelectedIndex;
                //MessageBox.Show(items[n].Id.ToString());

                EditWindow EditWindow = new EditWindow();
                EditWindow.Owner = this;
                EditWindow.ViewModel = n.ToString();
                
                EditWindow.ShowViewModel();
                EditWindow.ShowDialog();
                UpdateEmplList();


            }

        }

        /// <summary>
        /// Добавление нвого сотрудника
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddEmpl addEmpl = new AddEmpl();
            addEmpl.Owner = this;
            addEmpl.GetListDep();
            addEmpl.ShowDialog();

            UpdateEmplList();
        }
    }
}
