﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Employee
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }

        public int IdDep { get; set; }

        public string DepName { get; set; }

        public override string ToString()
        {
            return $"{Id}\t {Name}\t {Age} \t {DepName}";
        }


    }
}
