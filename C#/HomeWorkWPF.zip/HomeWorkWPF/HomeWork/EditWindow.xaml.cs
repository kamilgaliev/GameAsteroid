﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomeWork
{
    /// <summary>
    /// Логика взаимодействия для EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        MainWindow mainW;
        Employee.Employee empl = new Employee.Employee();
        ObservableCollection<Department.Department> itemsDept = new ObservableCollection<Department.Department>();

        public EditWindow()
        {
            InitializeComponent();
           
        }
        public string ViewModel { get; set; }

        /// <summary>
        /// Получаем данные сотрудника
        /// </summary>
        public void GetEmpl()
        {
            mainW = Owner as MainWindow;
            empl = mainW.items[Convert.ToInt32(ViewModel)];
        }

        /// <summary>
        /// Получаем список отделов
        /// </summary>
        public void GetListDep()
        {
            mainW = Owner as MainWindow;
            itemsDept = mainW.itemsDept;
        }

        /// <summary>
        /// Вывод данных на экран
        /// </summary>
        public void ShowViewModel()
        {
            GetEmpl();
            GetListDep();
            //textBlock.Text = ViewModel;
            EmplName.Text = empl.Name;
            EmplAge.Text = empl.Age.ToString();
            DepBox.ItemsSource = itemsDept;
            DepBox.SelectedIndex = itemsDept.IndexOf(itemsDept.First(x => x.Id == empl.IdDep));
        }

        /// <summary>
        /// Сохранение изменении
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveBTN_Click(object sender, RoutedEventArgs e)
        {
            mainW = Owner as MainWindow;
            empl.Name = EmplName.Text;
            empl.Age = Convert.ToInt32(EmplAge.Text);
            empl.IdDep = itemsDept[DepBox.SelectedIndex].Id;
            mainW.items[Convert.ToInt32(ViewModel)] = empl;

            this.Close();
        }
    }
}
